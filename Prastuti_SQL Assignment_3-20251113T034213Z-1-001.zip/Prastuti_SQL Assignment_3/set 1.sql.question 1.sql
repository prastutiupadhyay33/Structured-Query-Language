create database Employess;
use Employess;
create table Employes(emp_id INT PRIMARY KEY AUTO_INCREMENT, 
name_5 VARCHAR(50), 
department VARCHAR(30), 
experience INT, 
salary INT, 
joining_date DATE,
bonus int 
);
INSERT INTO Employes (emp_id,name_4, department, experience, salary, joining_date,bonus) VALUES (02,'Amrit','HR', 4, 40000, '2005-07-04',2000), 
(03,'Priya', 'HR', 3, 40000, '2021-05-14',3000),
(04,'Ravi', 'Sales', 8, 75000,'2016-11-23',4000), 
(05,'Sneha', 'IT', 2, 35000, '2023-02-18',54000), 
(06,'Karan', 'Finance', 10, 90000, '2014-04-05',2000),
(07,'Tina', 'Sales', 5, 55000, '2019-09-12',5600);
select*from Employes where department="IT";
set sql_safe_updates=0;
UPDATE Employes SET bonus = bonus * 1.20 WHERE salary > 70000; 
SELECT emp_id, name_5, department, salary,
    CASE 
        WHEN salary >= 80000 THEN 'High'
        WHEN salary BETWEEN 50000 AND 79999 THEN 'Medium'
        ELSE 'Low'
    END AS salary_level
FROM Employes;
SELECT department, AVG(bonus) AS avg_bonus FROM Employes  GROUP BY department;
SELECT department, AVG(bonus) AS avg_bonus FROM Employes GROUP BY department HAVING AVG(bonus) > 4000;
SELECT department, SUM(salary + bonus) AS total_salary_bonus FROM Employes GROUP BY department;
UPDATE Employess  SET salary = salary * 1.10  WHERE department = 'Finance';
SELECT MAX(salary) AS max_salary, MIN(salary) AS min_salary FROM Employes;
SELECT * FROM Employes order by bonus desc;
SELECT department, COUNT(*) AS Employess_count FROM Employes GROUP BY department HAVING COUNT(*) > 1;
select*from Employes;

